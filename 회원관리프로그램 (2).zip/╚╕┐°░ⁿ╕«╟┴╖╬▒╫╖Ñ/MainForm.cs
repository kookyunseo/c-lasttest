﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            InsertForm subFrom = new InsertForm();
            subFrom.ShowDialog();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            SelectForm subForm = new SelectForm();
            subForm.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (tbUpdelId.Text == "")
            {
                MessageBox.Show("수정할 아이디를 먼저 입력하세요");
                return;
            }

            String selectedID = tbUpdelId.Text;

            UpdateForm subFrom = new UpdateForm(selectedID);
            subFrom.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (tbUpdelId.Text == "")
            {
                MessageBox.Show("삭제할 아이디를 먼저 입력하세요");
                return;
            }

            string selectedID = tbUpdelId.Text;

            DeleteForm subFrom = new DeleteForm(selectedID);
            subFrom.ShowDialog();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
