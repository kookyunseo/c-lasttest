﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램.Forms
{
    public partial class Form_Dashboard : Form
    {

        int paneWidth;
        bool isCollapsed;
        public Form_Dashboard()
        {
            InitializeComponent();
            timer2.Start();
            paneWidth  = panelLeft.Width;
  
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(isCollapsed)
            {
                panelLeft.Width = panelLeft.Width + 10;
                if(panelLeft.Width >= paneWidth)
                {
                    timer1.Stop();
                    isCollapsed = false;
                    this.Refresh();
                }
            }
            else
            {
                panelLeft.Width = panelLeft.Width - 10;
                if(panelLeft.Width <= 85)
                {
                    timer1.Stop();
                    isCollapsed = true;
                    this.Refresh();
                }
            }
        }

        private void Form_Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
        private void moveSidepanel(Control btn)
        {
            panelSlide.Top = btn.Top;
            panelSlide.Height=btn.Height;
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            moveSidepanel(btnHome);
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            moveSidepanel(btnSales);
        }

        private void btnPurchage_Click(object sender, EventArgs e)
        {
            moveSidepanel(btnPurchage);
        }

        private void btnExpenses_Click(object sender, EventArgs e)
        {
            moveSidepanel(btnExpenses);
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            moveSidepanel(btnUsers);
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            moveSidepanel(btnSetting);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            labelTime.Text = dt.ToString("HH:MM:ss");
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
