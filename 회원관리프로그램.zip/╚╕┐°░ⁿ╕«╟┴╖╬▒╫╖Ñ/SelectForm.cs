﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램
{

    public partial class SelectForm : Form
    {
        string connStr;
        SqlConnection conn;
        SqlCommand cmd;

        public SelectForm()
        {
            InitializeComponent();
            connStr = "Server=localhost\\SQLEXPRESS;Database=master;Trusted_Connection=True;";
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand();
            cmd.Connection = conn;
        }

        private string GetData4()
        {
            return data4;
        }

        private void SelectForm_Load(object sender, EventArgs e, string data4)
        {
            listMember.View = View.Details;
            listMember.GridLines = true;
            int listWidth = listMember.Width;
            listMember.Columns.Add("아이디", (int)(listWidth * 0.2));
            listMember.Columns.Add("이름", (int)(listWidth * 0.3));
            listMember.Columns.Add("이메일", (int)(listWidth * 0.3));
            listMember.Columns.Add("출생연도", (int)(listWidth * 0.2));

            string data1, data2, data3, data4;

            cmd.CommandText = "SELECT * FROM member";
            SqlDataReader reader = cmd.ExecuteReader();

            listMember.Items.Clear();
            ListViewItem item;
            while (reader.Read())
            {
                data1 = reader.GetString(0);
                data2 = reader.GetString(1);
                data3 = reader.GetString(2);
                data4 = reader.GetInt32(3).ToString();

                item = new ListViewItem(data1);
                item.SubItems.Add(data2);
                item.SubItems.Add(data3);
                item.SubItems.Add(data4);

                listMember.Items.Add(item);
            }
            reader.Close();
        }

        private void SelectForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            conn.Close();
        }

        private void btnSelUpdate_Click(object sender, EventArgs e)
        {
            if (listMember.SelectedItems.Count == 0)
            {
                MessageBox.Show("수정할 아이디를 먼저 선택하세요.");
                return;
            }
            string selectedID = listMember.SelectedItems[0].Text;

            UpdateForm subFrom = new UpdateForm(selectedID);
            subFrom.ShowDialog();
            this.Close();
        }

        private void btnSelDelte_Click(object sender, EventArgs e)
        {
            if (listMember.SelectedItems.Count == 0)
            {
                MessageBox.Show("삭제할 아이디를 먼저 선택하세요");
                return;
            }
            string selectedID = listMember.SelectedItems[0].Text;

            DeleteForm subFrom = new DeleteForm(selectedID);
            subFrom.ShowDialog();
            this.Close();
        }
    }


}
