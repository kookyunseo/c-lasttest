﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 회원관리프로그램
{
    public partial class 직원_조회 : Form
    {
        public 직원_조회()
        {
            InitializeComponent();
        }

        string connStr;
        SqlConnection conn;
        SqlCommand cmd;

        private void btnSelDelte_Click(object sender, EventArgs e)
        {

        }

        private void btnSelUpdate_Click(object sender, EventArgs e)
        {

        }

        private void 직원_조회_Load(object sender, EventArgs e)
        {
            connStr = "Server = localhost\\SQLEXPRESS; Database = master;Trusted_Connection = True;";
            conn = new SqlConnection();
            conn.Open();

            cmd = new SqlCommand();
            cmd.Connection = conn;

            listMember.View = View.Details;
            listMember.GridLines = true;
            int listWidth = listMember.Width;
            listMember.Columns.Add("아이디", (int)(listWidth * 0.2));
            listMember.Columns.Add("이름", (int)(listWidth * 0.3));
            listMember.Columns.Add("이메일", (int)(listWidth * 0.3));
            listMember.Columns.Add("출생연도", (int)(listWidth * 0.2));

            string data1, data2, data3, data4;

            cmd.CommandText = "SELECT * FROM member";
            SqlDataReader reader = cmd.ExecuteReader();

            listMember.Items.Clear();
            ListViewItem item;
            while (reader.Read())
            {
                data1 = reader.GetString(0);
                data2 = reader.GetString(1);
                data3 = reader.GetString(2);
                data4 = reader.GetInt32(3).ToString();

                item = new ListViewItem(data1);
                item.SubItems.Add(data2);
                item.SubItems.Add(data3);
                item.SubItems.Add(data4);

                listMember.Items.Add(item);
            }
            reader.Close();
        }

        private void 직원_조회_FormClosed(object sender, FormClosedEventArgs e)
        {
            conn.Close();
        }

        private void btnSelUpdate_Click_1(object sender, EventArgs e)
        {
            {
                if (listMember.SelectedItems.Count == 0)
                {
                    MessageBox.Show("수정할 아이디를 먼저 선택하세요.");
                    return;
                }
                string selectedID = listMember.SelectedItems[0].Text;

                UpdateForm subFrom = new UpdateForm(selectedID);
                subFrom.ShowDialog();
                this.Close();
            }
        }

        private void btnSelDelte_Click_1(object sender, EventArgs e)
        {
            if (listMember.SelectedItems.Count == 0)
            {
                MessageBox.Show("삭제할 아이디를 먼저 선택하세요");
                return;
            }
            string selectedID = listMember.SelectedItems[0].Text;

            DeleteForm subFrom = new DeleteForm(selectedID);
            subFrom.ShowDialog();
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedValue = comboBox1.SelectedItem.ToString();
            string[] inStrAry;

            if (selectedValue == "직원")
            {
                inStrAry = File.ReadAllLines("직원.txt");

                foreach(string inStr in inStrAry)
                {
                    Console.WriteLine(inStr);
                }
            }

            else if (selectedValue == "고객")
            {
                inStrAry = File.ReadAllLines("고객.txt");

                foreach (string inStr in inStrAry)
                {
                    Console.WriteLine(inStr);
                }
            }
                

        }
    }
}
