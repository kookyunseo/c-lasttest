﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }
        string connStr;
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader reader;

        private void InsertForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            conn.Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            connStr = "Server = localhost\\SQLEXPRESS;Data = master;Trusted_Connection = True;";
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand(connStr);
            cmd.Connection = conn;

            string data1, data2, data3, data4, sql;

            data1 = tbId.Text;
            data2 = tbName.Text;
            data3 = tbEmail.Text;
            data4 = tbBirth.Text;


            sql = "INSERT INTO member VALUES('"+data1+"','"+data2+"','"+data3+"',"+data4+")";
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();


            MessageBox.Show("아이디(" + data1 + ")가 잘 입력되었습니다. 창이 닫힙니다.");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
