﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            MainForm subFrom = new MainForm();
            subFrom.ShowDialog();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {

        }
    }
}
