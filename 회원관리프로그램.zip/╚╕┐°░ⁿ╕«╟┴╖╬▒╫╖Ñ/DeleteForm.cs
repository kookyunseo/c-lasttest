﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램
{
    public partial class DeleteForm : Form
    {
        string memberID;
        public DeleteForm(string paraID)
        {
            InitializeComponent();
            memberID = paraID;
        }

        string connStr;
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader reader;
        private void DeleteForm_Load(object sender, EventArgs e)
        {
            connStr = "Server = localhost\\SQLEXPRESS;Data = master;Trusted_Connection=Ture;";
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand();
            cmd.Connection = conn;

            cmd.CommandText = "SELECT * FROM member WHERE id = '"+ memberID+"'";
            reader = cmd.ExecuteReader();

            if (!reader.Read()) {
                reader.Close();
                MessageBox.Show("아이디(" + memberID + ")는 회원이 아닙니다.");
                this.Close();
            }
            else
            {
                string data1, data2, data3, data4;
                data1 = reader.GetString(0).Trim();
                data2 = reader.GetString(1).Trim();
                data3 = reader.GetString(2).Trim();
                data4 = reader.GetInt32(3).ToString();

                tbId.Text = data1;
                tbName.Text = data2;
                tbEmail.Text = data3;
                    tbBirth.Text = data4;
                reader.Close();
            }
        }

        private void DeleteForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            conn.Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string data1, sql;
            
            data1=tbId.Text;

            sql = "DELETE FROM member WHERE id = '" + data1 + "'";
            cmd.CommandText= sql;
            cmd.ExecuteNonQuery();

            MessageBox.Show("아이디(" + memberID + ")가 잘 삭제되었습니다. 창이 닫힙니다.");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
