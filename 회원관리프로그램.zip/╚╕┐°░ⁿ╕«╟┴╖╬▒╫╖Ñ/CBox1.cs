﻿namespace 회원관리프로그램
{
    internal class CBox1
    {
        public static object SelectedItem { get; internal set; }
    }
}