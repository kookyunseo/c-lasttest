﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 회원관리프로그램
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }
        string connStr;
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataReader reader;

        private void btnOk_Click(object sender, EventArgs e)
        {
            connStr = "Server=localhost\\SQLEXPRESS;Database=master;Trusted_Connection=True;";
            conn = new SqlConnection(connStr);
            conn.Open();

            cmd = new SqlCommand();
            cmd.Connection = conn;


            string data1, data2, data3, data4, data5, sql;

            data1 = tbId.Text;
            data2 = tbName.Text;
            data3 = tbEmail.Text;
            data4 = tbBirth.Text;
            data5 = password.Text; 

            sql = "INSERT INTO member VALUES(@data1, @data2, @data3, @data4, @data5)";
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@data1", data1);
            cmd.Parameters.AddWithValue("@data2", data2);
            cmd.Parameters.AddWithValue("@data3", data3);
            cmd.Parameters.AddWithValue("@data4", data4);
            cmd.Parameters.AddWithValue("@data5", data5);
            cmd.ExecuteNonQuery();

            MessageBox.Show("아이디(" + data1 + ")가 잘 입력되었습니다. 창이 닫힙니다.");
            this.Close();
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbId_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbName_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbBirth_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
