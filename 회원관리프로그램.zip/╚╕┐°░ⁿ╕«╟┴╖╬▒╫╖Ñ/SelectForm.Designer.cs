﻿namespace 회원관리프로그램
{
    partial class SelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSelUpdate = new System.Windows.Forms.Button();
            this.btnSelDelte = new System.Windows.Forms.Button();
            this.listMember = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSelUpdate
            // 
            this.btnSelUpdate.Location = new System.Drawing.Point(54, 364);
            this.btnSelUpdate.Name = "btnSelUpdate";
            this.btnSelUpdate.Size = new System.Drawing.Size(136, 40);
            this.btnSelUpdate.TabIndex = 0;
            this.btnSelUpdate.Text = "선택 회원 수정";
            this.btnSelUpdate.UseVisualStyleBackColor = true;
            this.btnSelUpdate.Click += new System.EventHandler(this.btnSelUpdate_Click);
            // 
            // btnSelDelte
            // 
            this.btnSelDelte.Location = new System.Drawing.Point(332, 364);
            this.btnSelDelte.Name = "btnSelDelte";
            this.btnSelDelte.Size = new System.Drawing.Size(136, 40);
            this.btnSelDelte.TabIndex = 1;
            this.btnSelDelte.Text = "선택 회원 삭제";
            this.btnSelDelte.UseVisualStyleBackColor = true;
            this.btnSelDelte.Click += new System.EventHandler(this.btnSelDelte_Click);
            // 
            // listMember
            // 
            this.listMember.HideSelection = false;
            this.listMember.Location = new System.Drawing.Point(32, 97);
            this.listMember.Name = "listMember";
            this.listMember.Size = new System.Drawing.Size(455, 240);
            this.listMember.TabIndex = 2;
            this.listMember.UseCompatibleStateImageBehavior = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(172, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 37);
            this.label1.TabIndex = 3;
            this.label1.Text = "회원 조회 ";
            // 
            // SelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listMember);
            this.Controls.Add(this.btnSelDelte);
            this.Controls.Add(this.btnSelUpdate);
            this.Name = "SelectForm";
            this.Text = "회원 조회";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SelectForm_FormClosed);
            System.EventHandler eventHandler = new System.EventHandler(this.SelectForm_Load);
            this.Load += eventHandler;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSelUpdate;
        private System.Windows.Forms.Button btnSelDelte;
        private System.Windows.Forms.ListView listMember;
        private System.Windows.Forms.Label label1;
    }
}